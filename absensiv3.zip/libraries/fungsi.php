<?php
	Class Fungsi {
	protected $ci;

	public function count_belum() {
		$this->ci->load->model('belum_m');
	}
	}

?>